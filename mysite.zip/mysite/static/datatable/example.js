	
new DataTable('#example');
console.log('DataTable initialized');